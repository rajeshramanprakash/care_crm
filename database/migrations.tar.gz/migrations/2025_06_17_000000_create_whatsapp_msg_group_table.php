<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('whatsapp_msg_group', function (Blueprint $table) {
            $table->id();
            $table->string('whatsapp_number'); // WhatsApp number
            $table->string('executive_ids'); // CSV of allowed executive IDs, e.g. "1,3,4,12"
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('whatsapp_msg_group');
    }
};