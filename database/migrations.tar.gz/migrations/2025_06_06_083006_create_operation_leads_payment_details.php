<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('operation_leads_payment_details', function (Blueprint $table) {
            $table->id();
            $table->foreignId('operation_lead_id')->constrained('operation_leads');
            $table->datetime('deployment_date')->nullable();
            $table->string('deployment_status')->nullable();
            $table->string('payment_received')->nullable();
            $table->datetime('received_date')->nullable();
            $table->string('screenshot')->nullable();
            $table->string('invoice')->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('operation_leads_payment_details');
    }
};
