<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('operation_deployment_details', function (Blueprint $table) {
            $table->id();
            $table->foreignId('operation_lead_id')->constrained('operation_leads');
            $table->string('deployment_date');
            $table->string('deployment_status')->nullable();
            $table->tinyInteger('vendor_id')->nullable();
            $table->string('staff_name')->nullable();
            $table->decimal('vendor_rate_per_day', 12, 2)->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('operation_deployment_details');
    }
};
