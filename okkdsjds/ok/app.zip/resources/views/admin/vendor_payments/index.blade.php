@extends('admin.layouts.app')

@section('title', 'Vendor Payment History | Admin')

@section('header-css')
<style>
    .search-section {
        background: #fff;
        border-radius: 8px;
        box-shadow: 0 0.125rem 0.25rem rgba(0, 0, 0, 0.075);
        border: 1px solid #dee2e6;
        padding: 20px;
        margin-bottom: 20px;
    }

    .search-input {
        width: 100%;
        padding: 12px 16px;
        border: 1px solid #ced4da;
        border-radius: 4px;
        font-size: 14px;
        transition: border-color 0.15s ease-in-out, box-shadow 0.15s ease-in-out;
    }

    .search-input:focus {
        outline: none;
        border-color: #80bdff;
        box-shadow: 0 0 0 0.2rem rgba(0, 123, 255, 0.25);
    }

    .vendor-table {
        background: #fff;
        border-radius: 8px;
        box-shadow: 0 0.125rem 0.25rem rgba(0, 0, 0, 0.075);
        border: 1px solid #dee2e6;
        overflow: hidden;
    }

    .table-header {
        background: #fe992e;
        color: white;
        padding: 20px;
    }

    .table-title {
        color: white;
        font-size: 18px;
        font-weight: 600;
        margin: 0;
    }

    .table-responsive {
        overflow-x: auto;
    }

    .table {
        width: 100%;
        border-collapse: collapse;
        margin-bottom: 0;
    }

    .table th {
        background: #f8f9fa;
        color: #495057;
        font-weight: 600;
        font-size: 12px;
        padding: 12px 16px;
        text-align: left;
        border-bottom: 2px solid #dee2e6;
        text-transform: uppercase;
        letter-spacing: 0.5px;
    }

    .table td {
        padding: 12px 16px;
        border-bottom: 1px solid #dee2e6;
        color: #212529;
        font-size: 13px;
        vertical-align: middle;
    }

    .table tr:hover {
        background: #f8f9fa;
    }

    .vendor-info {
        display: flex;
        flex-direction: column;
    }

    .vendor-name {
        font-weight: 600;
        color: #212529;
        margin-bottom: 4px;
    }

    .vendor-contact {
        font-size: 12px;
        color: #6c757d;
    }

    .stats-info {
        display: flex;
        flex-direction: column;
        gap: 4px;
    }

    .stat-row {
        display: flex;
        justify-content: space-between;
        align-items: center;
        font-size: 12px;
    }

    .stat-label {
        color: #6c757d;
        font-weight: 500;
    }

    .stat-value {
        font-weight: 600;
        color: #212529;
    }

    .action-buttons {
        display: flex;
        gap: 8px;
        justify-content: center;
    }

    .btn-vendor {
        padding: 8px 12px;
        border: none;
        border-radius: 4px;
        font-size: 12px;
        font-weight: 600;
        cursor: pointer;
        transition: all 0.15s ease-in-out;
        text-align: center;
        text-decoration: none;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        gap: 4px;
        min-width: 80px;
    }

    .btn-history {
        background: #17a2b8;
        color: white;
    }

    .btn-history:hover {
        background: #138496;
        color: white;
    }

    .btn-add-payment {
        background: #28a745;
        color: white;
    }

    .btn-add-payment:hover {
        background: #218838;
        color: white;
    }

    .btn-payment-details {
        background: #6f42c1;
        color: white;
    }

    .btn-payment-details:hover {
        background: #5a32a3;
        color: white;
    }

    .badge {
        padding: 6px 12px;
        border-radius: 4px;
        font-size: 11px;
        font-weight: 600;
        display: inline-flex;
        align-items: center;
        gap: 4px;
    }

    .badge-success {
        background: #d4edda;
        color: #155724;
    }

    .badge-warning {
        background: #fff3cd;
        color: #856404;
    }

    .badge-danger {
        background: #f8d7da;
        color: #721c24;
    }

    .badge-info {
        background: #d1ecf1;
        color: #0c5460;
    }

    .btn-primary {
        background: #007bff;
        color: white;
        border: none;
        padding: 12px 24px;
        border-radius: 4px;
        font-weight: 600;
        cursor: pointer;
        transition: all 0.15s ease-in-out;
    }

    .btn-primary:hover {
        background: #0056b3;
        color: white;
    }

    .alert {
        padding: 12px 16px;
        border-radius: 4px;
        margin-bottom: 20px;
        font-size: 14px;
    }

    .alert-success {
        background: #d4edda;
        color: #155724;
        border: 1px solid #c3e6cb;
    }

    .alert-error {
        background: #f8d7da;
        color: #721c24;
        border: 1px solid #f5c6cb;
    }

    .empty-state {
        text-align: center;
        padding: 40px 20px;
        color: #6b7280;
    }

    .empty-state i {
        font-size: 48px;
        margin-bottom: 20px;
        opacity: 0.5;
    }

    @media (max-width: 768px) {
        .action-buttons {
            flex-direction: column;
            gap: 4px;
        }

        .btn-vendor {
            min-width: 60px;
            font-size: 11px;
            padding: 6px 8px;
        }

        .table-responsive {
            font-size: 12px;
        }
    }
</style>
@endsection

@section('main')
<div class="content-wrapper">
    <div class="container-fluid">
        <!-- Page Header -->
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h1 class="h3 mb-0 text-gray-800">Vendor Payment History</h1>
            <div>
                <a href="{{ route('admin.vendor_payments.index') }}" class="btn btn-outline-primary">
                    <i class="fas fa-list"></i> All Payments
                </a>
            </div>
        </div>

        <!-- Search Section -->
        <div class="search-section">
            <div class="row">
                <div class="col-md-6">
                    <label for="vendorSearch" class="form-label fw-bold mb-2">Search Vendors</label>
                    <input type="text" id="vendorSearch" class="search-input" placeholder="Search by vendor name, contact number, or email...">
                </div>
                <div class="col-md-6 d-flex align-items-end">
                    <div class="d-flex gap-2">
                        <button type="button" class="btn btn-outline-secondary" onclick="clearSearch()">
                            <i class="fas fa-times"></i> Clear
                        </button>
                        <span class="text-muted align-self-center" id="searchResults">
                            Showing all vendors
                        </span>
                    </div>
                </div>
            </div>
        </div>

        <!-- Vendors Table -->
        <div class="vendor-table">
            <div class="table-header">
                <h3 class="table-title">Vendor Payment History</h3>
            </div>
            <div class="table-responsive" style="max-height: 400px; overflow-y: auto;">
                <table class="table" id="vendorsTable">
                    <thead>
                        <tr>
                            <th>Vendor</th>
                            <th>Contact</th>
                            <th>Total Paid</th>
                            <th>Payments Count</th>
                            <th>Last Payment</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        @forelse($vendors as $vendor)
                        <tr class="vendor-row" data-vendor-id="{{ $vendor->id }}" data-vendor-name="{{ strtolower($vendor->name) }}" data-vendor-contact="{{ strtolower($vendor->contact_no ?? '') }}" data-vendor-email="{{ strtolower($vendor->email ?? '') }}">
                            <td>
                                <div class="vendor-info">
                                    <div class="vendor-name">{{ $vendor->name }}</div>
                                    <div class="vendor-contact">{{ $vendor->email ?: 'No Email' }}</div>
                                </div>
                            </td>
                            <td>{{ $vendor->contact_no ?: 'No Contact' }}</td>
                            <td>
                                <div class="stats-info">
                                    <div class="stat-row">
                                        <span class="stat-label">Total:</span>
                                        <span class="stat-value">₹{{ number_format($vendor->total_paid, 2) }}</span>
                                    </div>
                                </div>
                            </td>
                            <td>
                                <div class="stats-info">
                                    <div class="stat-row">
                                        <span class="stat-label">Count:</span>
                                        <span class="stat-value">{{ $vendor->payments->count() }}</span>
                                    </div>
                                </div>
                            </td>
                            <td>
                                <div class="stats-info">
                                    <div class="stat-row">
                                        <span class="stat-label">Last:</span>
                                        <span class="stat-value">{{ $vendor->last_payment_date ? $vendor->last_payment_date->format('d-M-Y') : 'No Payments' }}</span>
                                    </div>
                                </div>
                            </td>
                            <td>
                                <div class="action-buttons">
                                    <button class="btn-vendor btn-history" onclick="viewVendorHistory({{ $vendor->id }}, '{{ $vendor->name }}')" title="View Payment History">
                                        <i class="fas fa-history"></i>
                                        History
                                    </button>
                                    <button class="btn-vendor btn-add-payment" onclick="addVendorPayment({{ $vendor->id }}, '{{ $vendor->name }}')" title="Add New Payment">
                                        <i class="fas fa-plus"></i>
                                        Add
                                    </button>
                                    <button class="btn-vendor btn-payment-details" onclick="viewVendorPaymentDetails({{ $vendor->id }}, '{{ $vendor->name }}')" title="View Payment Details">
                                        <i class="fas fa-rupee-sign"></i>
                                        Details
                                    </button>
                                </div>
                            </td>
                        </tr>
                        @empty
                        <tr>
                            <td colspan="6" class="text-center">
                                <div class="empty-state">
                                    <i class="fas fa-users"></i>
                                    <h4>No Vendors Found</h4>
                                    <p>There are no vendors available to display payment history.</p>
                                </div>
                            </td>
                        </tr>
                        @endforelse
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<!-- Payment History Modal -->
<div class="modal fade" id="paymentHistoryModal" tabindex="-1" aria-labelledby="paymentHistoryModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-xl">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="paymentHistoryModalLabel">Payment History</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <h6 id="vendorNameDisplay" class="mb-3"></h6>
                <div class="table-responsive">
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th>Date</th>
                                <th>Amount</th>
                                <th>Method</th>
                                <th>Transaction ID</th>
                                <th>Status</th>
                                <th>Screenshot</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody id="paymentHistoryBody">
                            <!-- Payment history will be loaded here -->
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Add Payment Modal -->
<div class="modal fade" id="addPaymentModal" tabindex="-1" aria-labelledby="addPaymentModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="addPaymentModalLabel">Add New Payment</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form id="addPaymentForm" enctype="multipart/form-data">
                @csrf
                <input type="hidden" id="payment_vendor_id" name="vendor_id">
                <div class="modal-body">
                    <h6 id="addPaymentVendorName" class="mb-3"></h6>
                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group mb-3">
                                <label class="form-label">Amount (₹) *</label>
                                <input type="number" class="form-control" name="amount" step="0.01" min="0.01" required>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group mb-3">
                                <label class="form-label">Payment Method *</label>
                                <select class="form-control" name="payment_method" id="payment_method" required>
                                    <option value="">Select Method</option>
                                    <option value="bank_transfer">Bank Transfer</option>
                                    <option value="upi">UPI</option>
                                    <option value="cheque">Cheque</option>
                                </select>
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group mb-3">
                                <label class="form-label">Payment Date *</label>
                                <input type="date" class="form-control" name="payment_date" max="{{ date('Y-m-d') }}" required>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group mb-3" id="transaction_id_group">
                                <label class="form-label">Transaction ID</label>
                                <input type="text" class="form-control" name="transaction_id" id="transaction_id" placeholder="Enter transaction ID">
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group mb-3" id="reference_number_group">
                                <label class="form-label">Reference Number</label>
                                <input type="text" class="form-control" name="reference_number" id="reference_number" placeholder="Enter reference number">
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group mb-3">
                                <label class="form-label">Payment Screenshot</label>
                                <input type="file" class="form-control" name="screenshot" accept="image/*">
                            </div>
                        </div>
                    </div>

                    <div class="form-group mb-3">
                        <label class="form-label">Description</label>
                        <textarea class="form-control" name="description" rows="3" placeholder="Enter payment description"></textarea>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary" id="submitPaymentBtn">
                        <span class="btn-text">Record Payment</span>
                        <span class="btn-loading" style="display: none;">
                            <span class="loading-spinner"></span> Recording...
                        </span>
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- View Payment Modal -->
<div class="modal fade" id="viewPaymentModal" tabindex="-1" aria-labelledby="viewPaymentModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="viewPaymentModalLabel">Payment Details</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body" id="viewPaymentBody">
                <!-- Payment details will be loaded here -->
            </div>
        </div>
    </div>
</div>

<!-- Edit Payment Modal -->
<div class="modal fade" id="editPaymentModal" tabindex="-1" aria-labelledby="editPaymentModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="editPaymentModalLabel">Edit Payment</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form id="editPaymentForm" enctype="multipart/form-data">
                @csrf
                @method('PUT')
                <input type="hidden" id="edit_payment_id" name="payment_id">
                <input type="hidden" id="edit_vendor_id" name="vendor_id">
                <div class="modal-body">
                    <h6 id="editPaymentVendorName" class="mb-3"></h6>
                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group mb-3">
                                <label class="form-label">Amount (₹) *</label>
                                <input type="number" class="form-control" name="amount" id="edit_amount" step="0.01" min="0.01" required>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group mb-3">
                                <label class="form-label">Payment Method *</label>
                                <select class="form-control" name="payment_method" id="edit_payment_method" required>
                                    <option value="">Select Method</option>
                                    <option value="bank_transfer">Bank Transfer</option>
                                    <option value="upi">UPI</option>
                                    <option value="cheque">Cheque</option>
                                </select>
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group mb-3">
                                <label class="form-label">Payment Date *</label>
                                <input type="date" class="form-control" name="payment_date" id="edit_payment_date" required>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group mb-3">
                                <label class="form-label">Status *</label>
                                <select class="form-control" name="status" id="edit_status" required>
                                    <option value="pending">Pending</option>
                                    <option value="completed">Completed</option>
                                    <option value="failed">Failed</option>
                                </select>
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group mb-3" id="edit_transaction_id_group">
                                <label class="form-label">Transaction ID</label>
                                <input type="text" class="form-control" name="transaction_id" id="edit_transaction_id" placeholder="Enter transaction ID">
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group mb-3" id="edit_reference_number_group">
                                <label class="form-label">Reference Number</label>
                                <input type="text" class="form-control" name="reference_number" id="edit_reference_number" placeholder="Enter reference number">
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group mb-3">
                                <label class="form-label">New Screenshot</label>
                                <input type="file" class="form-control" name="screenshot" accept="image/*">
                                <small class="text-muted">Leave empty to keep existing screenshot</small>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group mb-3">
                                <label class="form-label">Current Screenshot</label>
                                <div id="currentScreenshotDisplay">
                                    <!-- Current screenshot will be displayed here -->
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="form-group mb-3">
                        <label class="form-label">Description</label>
                        <textarea class="form-control" name="description" id="edit_description" rows="3" placeholder="Enter payment description"></textarea>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary" id="updatePaymentBtn">
                        <span class="btn-text">Update Payment</span>
                        <span class="btn-loading" style="display: none;">
                            <span class="loading-spinner"></span> Updating...
                        </span>
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Screenshot View Modal -->
<div class="modal fade" id="screenshotModal" tabindex="-1" aria-labelledby="screenshotModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="screenshotModalLabel">Payment Screenshot</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body text-center">
                <img id="screenshotImage" src="" alt="Payment Screenshot" style="max-width: 100%; height: auto;">
            </div>
        </div>
    </div>
</div>

<!-- Vendor Payment Details Modal -->
<div class="modal fade" id="vendorPaymentDetailsModal" tabindex="-1" aria-labelledby="vendorPaymentDetailsModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-xl">
        <div class="modal-content">
            <div class="modal-header bg-success text-white">
                <h5 class="modal-title" id="vendorPaymentDetailsModalLabel">
                    <i class="fas fa-rupee-sign"></i> Vendor Payment Details
                </h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div id="vendorPaymentDetailsContent">
                    <!-- Content will be loaded here -->
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>
@endsection

@section('footer-script')
<script>
$(document).ready(function() {
    // Set default payment date to today
    $('input[name="payment_date"]').val('{{ date("Y-m-d") }}');

    // Payment method change handler for add payment modal
    $('#payment_method').on('change', function() {
        togglePaymentFields($(this).val(), 'add');
    });

    // Payment method change handler for edit payment modal
    $('#edit_payment_method').on('change', function() {
        togglePaymentFields($(this).val(), 'edit');
    });

    // Payment form submission
    $('#addPaymentForm').on('submit', function(e) {
        e.preventDefault();

        const formData = new FormData(this);
        const submitBtn = $('#submitPaymentBtn');
        const btnText = submitBtn.find('.btn-text');
        const btnLoading = submitBtn.find('.btn-loading');

        // Show loading state
        btnText.hide();
        btnLoading.show();
        submitBtn.prop('disabled', true);

        $.ajax({
            url: '{{ route("admin.vendor_payments.store") }}',
            type: 'POST',
            data: formData,
            processData: false,
            contentType: false,
            success: function(response) {
                if (response.status === 'success') {
                    showAlert('success', response.message);
                    $('#addPaymentModal').modal('hide');
                    $('#addPaymentForm')[0].reset();
                    $('input[name="payment_date"]').val('{{ date("Y-m-d") }}');

                    // Refresh the vendor card stats
                    const vendorId = $('#payment_vendor_id').val();
                    refreshVendorStats(vendorId);

                    // Refresh vendor payment details modal if it's open
                    refreshVendorPaymentDetailsModal(vendorId);
                } else {
                    showAlert('error', response.message || 'Error recording payment');
                }
            },
            error: function(xhr) {
                let message = 'Error recording payment';
                if (xhr.responseJSON && xhr.responseJSON.message) {
                    message = xhr.responseJSON.message;
                } else if (xhr.responseJSON && xhr.responseJSON.errors) {
                    message = Object.values(xhr.responseJSON.errors).flat().join('<br>');
                }
                showAlert('error', message);
            },
            complete: function() {
                // Reset button state
                btnText.show();
                btnLoading.hide();
                submitBtn.prop('disabled', false);
            }
        });
    });

    // Edit payment form submission
    $('#editPaymentForm').on('submit', function(e) {
        e.preventDefault();

        const formData = new FormData(this);
        const paymentId = $('#edit_payment_id').val();
        const submitBtn = $('#updatePaymentBtn');
        const btnText = submitBtn.find('.btn-text');
        const btnLoading = submitBtn.find('.btn-loading');

        // Show loading state
        btnText.hide();
        btnLoading.show();
        submitBtn.prop('disabled', true);

        $.ajax({
            url: `/admin/vendor-payments/${paymentId}`,
            type: 'POST',
            data: formData,
            processData: false,
            contentType: false,
            success: function(response) {
                if (response.status === 'success') {
                    showAlert('success', response.message);
                    $('#editPaymentModal').modal('hide');

                    // Refresh the payment history modal
                    const vendorId = $('#edit_vendor_id').val();
                    const vendorName = $('#editPaymentVendorName').text();
                    if (vendorId && vendorName) {
                        viewVendorHistory(vendorId, vendorName);
                        refreshVendorStats(vendorId);
                        refreshVendorPaymentDetailsModal(vendorId);
                    }
                } else {
                    showAlert('error', response.message || 'Error updating payment');
                }
            },
            error: function(xhr) {
                let message = 'Error updating payment';
                if (xhr.responseJSON && xhr.responseJSON.message) {
                    message = xhr.responseJSON.message;
                } else if (xhr.responseJSON && xhr.responseJSON.errors) {
                    message = Object.values(xhr.responseJSON.errors).flat().join('<br>');
                }
                showAlert('error', message);
            },
            complete: function() {
                // Reset button state
                btnText.show();
                btnLoading.hide();
                submitBtn.prop('disabled', false);
            }
        });
    });
});

// View vendor payment history
function viewVendorHistory(vendorId, vendorName) {
    $('#vendorNameDisplay').text(vendorName);
    $('#paymentHistoryBody').html('<tr><td colspan="7" class="text-center">Loading...</td></tr>');
    $('#paymentHistoryModal').modal('show');

    $.ajax({
        url: `/admin/vendor-payments/vendor/${vendorId}`,
        type: 'GET',
        success: function(response) {
            if (response.payments && response.payments.length > 0) {
                let html = '';
                response.payments.forEach(function(payment) {
                    html += `
                        <tr>
                            <td>${payment.formatted_payment_date}</td>
                            <td><strong>₹${parseFloat(payment.amount).toLocaleString('en-IN', {minimumFractionDigits: 2})}</strong></td>
                            <td><span class="badge badge-info">${payment.payment_method_text}</span></td>
                            <td>${payment.transaction_id || '-'}</td>
                            <td><span class="${payment.status_badge}">${payment.status}</span></td>
                            <td>
                                ${payment.screenshot ?
                                    `<img src="/storage/${payment.screenshot}" alt="Screenshot" class="screenshot-preview" onclick="viewScreenshot('/storage/${payment.screenshot}')" style="width: 30px; height: 30px; border-radius: 4px; cursor: pointer;">` :
                                    '-'
                                }
                            </td>
                            <td>
                                <div class="btn-group btn-group-sm">
                                    <button class="btn btn-outline-primary" onclick="viewPayment(${payment.id})" title="View">
                                        <i class="fas fa-eye"></i>
                                    </button>
                                    <button class="btn btn-outline-warning" onclick="editPayment(${payment.id})" title="Edit">
                                        <i class="fas fa-edit"></i>
                                    </button>
                                    <button class="btn btn-outline-danger" onclick="deletePayment(${payment.id})" title="Delete">
                                        <i class="fas fa-trash"></i>
                                    </button>
                                </div>
                            </td>
                        </tr>
                    `;
                });
                $('#paymentHistoryBody').html(html);
            } else {
                $('#paymentHistoryBody').html(`
                    <tr>
                        <td colspan="7" class="text-center">
                            <div class="empty-state">
                                <i class="fas fa-inbox"></i>
                                <p>No payments found for this vendor</p>
                            </div>
                        </td>
                    </tr>
                `);
            }
        },
        error: function() {
            $('#paymentHistoryBody').html(`
                <tr>
                    <td colspan="7" class="text-center text-danger">
                        Error loading payment history
                    </td>
                </tr>
            `);
        }
    });
}

// Add payment for specific vendor
function addVendorPayment(vendorId, vendorName) {
    $('#addPaymentVendorName').text(vendorName);
    $('#payment_vendor_id').val(vendorId);
    $('#addPaymentForm')[0].reset();
    $('input[name="payment_date"]').val('{{ date("Y-m-d") }}');

    // Hide optional fields initially
    $('#transaction_id_group').hide();
    $('#reference_number_group').hide();

    $('#addPaymentModal').modal('show');
}

// View payment details
function viewPayment(id) {
    $.get(`/admin/vendor-payments/${id}`, function(response) {
        const payment = response;
        const html = `
            <div class="row">
                <div class="col-md-6">
                    <p><strong>Vendor:</strong> ${payment.vendor.name}</p>
                    <p><strong>Contact:</strong> ${payment.vendor.contact_no}</p>
                    <p><strong>Amount:</strong> ₹${parseFloat(payment.amount).toLocaleString('en-IN', {minimumFractionDigits: 2})}</p>
                    <p><strong>Payment Method:</strong> ${payment.payment_method_text}</p>
                </div>
                <div class="col-md-6">
                    <p><strong>Date:</strong> ${payment.formatted_payment_date}</p>
                    <p><strong>Status:</strong> <span class="${payment.status_badge}">${payment.status}</span></p>
                    <p><strong>Transaction ID:</strong> ${payment.transaction_id || '-'}</p>
                    <p><strong>Reference:</strong> ${payment.reference_number || '-'}</p>
                </div>
            </div>
            ${payment.description ? `<p><strong>Description:</strong> ${payment.description}</p>` : ''}
            ${payment.screenshot ? `
                <div class="mt-3">
                    <strong>Screenshot:</strong><br>
                    <img src="/storage/${payment.screenshot}" alt="Screenshot" style="max-width: 100%; height: auto; border-radius: 8px;">
                </div>
            ` : ''}
        `;

        $('#viewPaymentBody').html(html);
        $('#viewPaymentModal').modal('show');
    });
}

// Edit payment
function editPayment(id) {
    // Fetch payment details and populate edit form
    $.get(`/admin/vendor-payments/${id}/edit`, function(response) {
        console.log('Edit payment response:', response); // Debug log
        const payment = response.payment;

        // Populate form fields
        $('#edit_payment_id').val(payment.id);
        $('#edit_vendor_id').val(payment.vendor_id);
        $('#edit_amount').val(payment.amount);
        $('#edit_payment_method').val(payment.payment_method);
        $('#edit_payment_date').val(payment.payment_date);
        $('#edit_status').val(payment.status);
        $('#edit_transaction_id').val(payment.transaction_id || '');
        $('#edit_reference_number').val(payment.reference_number || '');
        $('#edit_description').val(payment.description || '');
        $('#editPaymentVendorName').text(payment.vendor ? payment.vendor.name : 'Unknown Vendor');

        // Display current screenshot if exists
        if (payment.screenshot) {
            $('#currentScreenshotDisplay').html(`
                <img src="/storage/${payment.screenshot}" alt="Current Screenshot"
                     style="max-width: 100px; height: auto; border-radius: 4px; cursor: pointer;"
                     onclick="viewScreenshot('/storage/${payment.screenshot}')">
                <br><small class="text-muted">Click to view full size</small>
            `);
        } else {
            $('#currentScreenshotDisplay').html('<span class="text-muted">No screenshot uploaded</span>');
        }

        // Show edit modal
        $('#editPaymentModal').modal('show');

        // Trigger field visibility based on selected payment method
        togglePaymentFields(payment.payment_method, 'edit');
    }).fail(function() {
        showAlert('error', 'Error loading payment details for editing');
    });
}

// Delete payment
function deletePayment(id) {
    if (!confirm('Are you sure you want to delete this payment? This action cannot be undone.')) {
        return;
    }

    $.ajax({
        url: `/admin/vendor-payments/${id}`,
        type: 'DELETE',
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        },
        success: function(response) {
            if (response.status === 'success') {
                showAlert('success', response.message);
                // Refresh the payment history modal
                const vendorName = $('#vendorNameDisplay').text();
                if (vendorName) {
                    // Get vendor ID from the current payment history modal
                    const vendorRow = $('.vendor-row').filter(function() {
                        return $(this).find('.vendor-name').text() === vendorName;
                    });
                    const vendorId = vendorRow.data('vendor-id');
                    if (vendorId) {
                        viewVendorHistory(vendorId, vendorName);
                        refreshVendorStats(vendorId);
                        refreshVendorPaymentDetailsModal(vendorId);
                    }
                }
            } else {
                showAlert('error', response.message || 'Error deleting payment');
            }
        },
        error: function(xhr) {
            let message = 'Error deleting payment';
            if (xhr.responseJSON && xhr.responseJSON.message) {
                message = xhr.responseJSON.message;
            }
            showAlert('error', message);
        }
    });
}

// View screenshot
function viewScreenshot(src) {
    $('#screenshotImage').attr('src', src);
    $('#screenshotModal').modal('show');
}

// Search functionality
$(document).ready(function() {
    $('#vendorSearch').on('input', function() {
        const searchTerm = $(this).val().toLowerCase();
        const vendorRows = $('.vendor-row');
        let visibleCount = 0;

        vendorRows.each(function() {
            const vendorName = $(this).data('vendor-name');
            const vendorContact = $(this).data('vendor-contact');
            const vendorEmail = $(this).data('vendor-email');

            const matches = vendorName.includes(searchTerm) ||
                           vendorContact.includes(searchTerm) ||
                           vendorEmail.includes(searchTerm);

            if (matches) {
                $(this).show();
                visibleCount++;
            } else {
                $(this).hide();
            }
        });

        // Update search results count
        if (searchTerm === '') {
            $('#searchResults').text('Showing all vendors');
        } else {
            $('#searchResults').text(`Found ${visibleCount} vendor(s)`);
        }
    });
});

// Clear search
function clearSearch() {
    $('#vendorSearch').val('');
    $('.vendor-row').show();
    $('#searchResults').text('Showing all vendors');
}

// Refresh vendor statistics
function refreshVendorStats(vendorId) {
    $.get(`/admin/vendor-payments/vendor/${vendorId}`, function(response) {
        const vendor = response.vendor;
        const totalPaid = response.totalPaid;
        const paymentCount = response.payments.length;

        // Update the vendor table row stats
        const vendorRow = $(`.vendor-row[data-vendor-id="${vendorId}"]`);
        vendorRow.find('.stat-value').first().text(`₹${parseFloat(totalPaid).toLocaleString('en-IN', {minimumFractionDigits: 2})}`);
        vendorRow.find('.stat-value').eq(1).text(paymentCount);
    });
}

// Refresh vendor payment details modal if it's open
function refreshVendorPaymentDetailsModal(vendorId) {
    // Check if the vendor payment details modal is currently open
    const modal = document.getElementById('vendorPaymentDetailsModal');
    if (modal && modal.classList.contains('show')) {
        // Get the vendor name from the modal title or current context
        const vendorRow = $(`.vendor-row[data-vendor-id="${vendorId}"]`);
        const vendorName = vendorRow.find('.vendor-name').text();

        if (vendorName) {
            // Refresh the vendor payment details
            viewVendorPaymentDetails(vendorId, vendorName);
        }
    }
}

// Toggle payment fields based on payment method
function togglePaymentFields(paymentMethod, modalType) {
    const prefix = modalType === 'edit' ? 'edit_' : '';

    // Hide all optional fields initially
    $(`#${prefix}transaction_id_group`).hide();
    $(`#${prefix}reference_number_group`).hide();

    // Show fields based on payment method
    switch(paymentMethod) {
        case 'bank_transfer':
            $(`#${prefix}transaction_id_group`).show();
            $(`#${prefix}reference_number_group`).show();
            break;
        case 'upi':
            $(`#${prefix}transaction_id_group`).show();
            $(`#${prefix}reference_number_group`).hide();
            break;
        case 'cheque':
            $(`#${prefix}transaction_id_group`).hide();
            $(`#${prefix}reference_number_group`).show();
            break;
        default:
            // No method selected, hide all optional fields
            break;
    }
}

// View Vendor Payment Details Function
function viewVendorPaymentDetails(vendorId, vendorName) {
    // Show loading state
    document.getElementById('vendorPaymentDetailsContent').innerHTML = `
        <div class="text-center p-4">
            <div class="spinner-border text-primary" role="status">
                <span class="visually-hidden">Loading...</span>
            </div>
            <p class="mt-2">Loading vendor payment details...</p>
        </div>
    `;

    // Show modal
    $('#vendorPaymentDetailsModal').modal('show');

    // Fetch vendor payment details
    fetch(`/admin/operation-leads/vendor-payment-details/${vendorId}`)
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                updateVendorPaymentDetailsDisplay(data, vendorName);
            } else {
                document.getElementById('vendorPaymentDetailsContent').innerHTML = `
                    <div class="alert alert-danger">
                        <i class="fas fa-exclamation-triangle"></i>
                        Error loading vendor payment details: ${data.message || 'Unknown error'}
                    </div>
                `;
            }
        })
        .catch(error => {
            console.error('Error:', error);
            document.getElementById('vendorPaymentDetailsContent').innerHTML = `
                <div class="alert alert-danger">
                    <i class="fas fa-exclamation-triangle"></i>
                    Error loading vendor payment details. Please try again.
                </div>
            `;
        });
}

// Update vendor payment details display
function updateVendorPaymentDetailsDisplay(data, vendorName) {
    const content = document.getElementById('vendorPaymentDetailsContent');

    let html = `
        <div class="row mb-4">
            <div class="col-md-6">
                <div class="card bg-primary text-white">
                    <div class="card-body">
                        <h5 class="card-title"><i class="fas fa-user"></i> Vendor Information</h5>
                        <p class="card-text"><strong>Name:</strong> ${vendorName}</p>
                        <p class="card-text"><strong>Contact:</strong> ${data.vendor.contact_no || 'N/A'}</p>
                        <p class="card-text"><strong>Rate/Day:</strong> ₹${data.vendor.rate_per_day || 0}</p>
                    </div>
                </div>
            </div>
            <div class="col-md-6">
                <div class="card bg-success text-white">
                    <div class="card-body">
                        <h5 class="card-title"><i class="fas fa-rupee-sign"></i> Payment Summary</h5>
                        <p class="card-text"><strong>Total Earned (Verified Only):</strong> ₹${parseFloat(data.total_earned || 0).toLocaleString('en-IN', {minimumFractionDigits: 2})}</p>
                        <small class="text-muted">Only payments verified through deployment details are included</small>
                        <p class="card-text"><strong>Payments Made:</strong> ₹${parseFloat(data.total_payments_made || 0).toLocaleString('en-IN', {minimumFractionDigits: 2})}</p>
                        <p class="card-text"><strong>Remaining Amount:</strong> <span style="color: ${data.remaining_amount >= 0 ? '#fff' : '#ffcccb'}">₹${parseFloat(data.remaining_amount || 0).toLocaleString('en-IN', {minimumFractionDigits: 2})}</span></p>
                        <p class="card-text"><strong>Total Leads:</strong> ${data.total_leads || 0}</p>
                        <p class="card-text"><strong>Active Deployments:</strong> ${data.active_deployments || 0}</p>
                    </div>
                </div>
            </div>
        </div>
    `;

    if (data.leads && data.leads.length > 0) {
        html += `
            <div class="card">
                <div class="card-header">
                    <h5 class="mb-0"><i class="fas fa-list"></i> Lead Details & Payments (Verified Only)</h5>
                    <small class="text-muted">Only deployment details with verified payments are shown</small>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-striped table-hover">
                            <thead class="table-dark">
                                <tr>
                                    <th>Lead ID</th>
                                    <th>Customer</th>
                                    <th>Service</th>
                                    <th>Location</th>
                                    <th>Deployment Date</th>
                                    <th>From Date</th>
                                    <th>To Date</th>
                                    <th>Days</th>
                                    <th>Rate/Day</th>
                                    <th>Payment</th>
                                    <th>Verified</th>
                                    <th>Status</th>
                                </tr>
                            </thead>
                            <tbody>
        `;

        data.leads.forEach(lead => {
            const deploymentDate = lead.deployment_date ? new Date(lead.deployment_date).toLocaleDateString('en-IN') : 'N/A';
            const fromDate = lead.deployment_from_date ? new Date(lead.deployment_from_date).toLocaleDateString('en-IN') : 'N/A';
            const toDate = lead.deployment_to_date ? new Date(lead.deployment_to_date).toLocaleDateString('en-IN') : 'N/A';

            // Calculate days
            let days = 0;
            if (lead.deployment_from_date && lead.deployment_to_date) {
                const startDate = new Date(lead.deployment_from_date);
                const endDate = new Date(lead.deployment_to_date);
                const timeDiff = endDate.getTime() - startDate.getTime();
                days = Math.ceil(timeDiff / (1000 * 3600 * 24)) + 1;
            }

            // Status badge
            let statusBadge = '';
            switch(lead.deployment_status) {
                case 'Completed':
                    statusBadge = '<span class="badge bg-success">Completed</span>';
                    break;
                case 'In Progress':
                    statusBadge = '<span class="badge bg-warning">In Progress</span>';
                    break;
                case 'Pending':
                    statusBadge = '<span class="badge bg-info">Pending</span>';
                    break;
                case 'Cancelled':
                    statusBadge = '<span class="badge bg-danger">Cancelled</span>';
                    break;
                case 'Stop':
                    statusBadge = '<span class="badge bg-secondary">Stopped</span>';
                    break;
                default:
                    statusBadge = '<span class="badge bg-light text-dark">Unknown</span>';
            }

            html += `
                <tr>
                    <td><strong>#${lead.lead_id || 'N/A'}</strong></td>
                    <td>${lead.customer_name || 'N/A'}</td>
                    <td>${lead.service || 'N/A'}</td>
                    <td>${lead.location || 'N/A'}</td>
                    <td>${deploymentDate}</td>
                    <td>${fromDate}</td>
                    <td>${toDate}</td>
                    <td><span class="badge bg-primary">${days} days</span></td>
                    <td>₹${lead.vendor_rate_per_day || 0}</td>
                    <td><strong class="text-success">₹${lead.vendor_payment || 0}</strong></td>
                    <td><span class="badge bg-success"><i class="fas fa-check"></i> Verified</span></td>
                    <td>${statusBadge}</td>
                </tr>
            `;
        });

        html += `
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        `;
    } else {
        html += `
            <div class="alert alert-info">
                <i class="fas fa-info-circle"></i>
                No deployment details found for this vendor.
            </div>
        `;
    }

    content.innerHTML = html;
}

// Show alert
function showAlert(type, message) {
    const alertClass = type === 'success' ? 'alert-success' : 'alert-error';
    const alertHtml = `<div class="alert ${alertClass}">${message}</div>`;

    // Remove existing alerts
    $('.alert').remove();

    // Add new alert at the top
    $('.content-wrapper .container-fluid').prepend(alertHtml);

    // Auto remove after 5 seconds
    setTimeout(() => {
        $('.alert').fadeOut();
    }, 5000);
}
</script>
@endsection
